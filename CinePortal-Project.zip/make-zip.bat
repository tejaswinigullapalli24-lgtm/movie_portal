@echo off
title Creating Lightweight Project ZIP
cd /d "%~dp0"
echo ========================================================
echo  Creating CinePortal-Project.zip on your Desktop...
echo ========================================================

powershell -Command "$files = Get-ChildItem -Path . -Exclude 'node_modules', '.git'; Compress-Archive -Path $files -DestinationPath \"$env:USERPROFILE\Desktop\CinePortal-Project.zip\" -Force"

echo.
echo ========================================================
echo  DONE! Check your Desktop: CinePortal-Project.zip is ready!
echo  Size is very small and ready to send on WhatsApp / Drive.
echo ========================================================
pause
